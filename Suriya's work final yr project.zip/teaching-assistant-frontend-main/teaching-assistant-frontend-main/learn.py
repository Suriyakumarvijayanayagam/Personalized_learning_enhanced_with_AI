# enhanced_professional_learning_style_app.py

import streamlit as st

# Set up session state to remember learning style and scores
if 'learning_style' not in st.session_state:
    st.session_state.learning_style = None

if 'scores' not in st.session_state:
    st.session_state.scores = {'Visual': 0, 'Auditory': 0, 'Kinesthetic': 0, 'Reading/Writing': 0}

# Display the app title with a professional header
st.title("🧠 Learning Style Assessment")
st.markdown("""
    Welcome! This professional assessment will help identify your dominant learning style based on your preferences. 
    Please rate each statement below, and we'll provide you with a tailored learning style profile.
""")

st.markdown("---")

# Progress bar setup
questions = {
    "Visual": [
        "I find visual aids like diagrams, charts, and images helpful in understanding new concepts.",
        "I remember faces better than names.",
        "I like to visualize information to retain it better."
    ],
    "Auditory": [
        "I prefer listening to explanations rather than reading them.",
        "I remember things better if I say them out loud.",
        "I find it easy to follow spoken instructions without needing them written down."
    ],
    "Kinesthetic": [
        "I prefer hands-on activities to understand new concepts.",
        "I learn better through practice rather than theory.",
        "I enjoy using physical objects or tools to learn."
    ],
    "Reading/Writing": [
        "I prefer learning through reading books, articles, and notes.",
        "I take notes often and find it helps me remember information.",
        "I learn best when I can read instructions and study written materials."
    ]
}

# Loop through each learning style section and gather ratings
for learning_type, learning_questions in questions.items():
    st.markdown(f"### {learning_type} Learning Preferences")
    for question in learning_questions:
        rating = st.slider(question, 1, 5, 3, key=f"{learning_type}_{question}")
        st.session_state.scores[learning_type] += rating - 1  # Adjust for neutrality

    st.markdown("---")  # Divider for each section

# Button to calculate results
if st.button("Calculate My Learning Style"):
    # Determine the learning style with the highest score
    st.session_state.learning_style = max(st.session_state.scores, key=st.session_state.scores.get)

    # Display the results in a professional summary box
    st.markdown("### Your Learning Style Profile")
    st.success(f"**Your Dominant Learning Style:** {st.session_state.learning_style}")
    
    # Display a radar chart for a visual representation of the scores
    try:
        import plotly.express as px
        fig = px.bar(x=list(st.session_state.scores.keys()), 
                     y=list(st.session_state.scores.values()), 
                     labels={'x': 'Learning Style', 'y': 'Score'},
                     title="Learning Style Analysis")
        st.plotly_chart(fig)
    except ImportError:
        st.write("For a better visualization, consider installing Plotly.")

    # Display detailed scores for transparency
    st.markdown("#### Detailed Scores by Learning Style")
    for style, score in st.session_state.scores.items():
        st.write(f"- **{style}**: {score} points")

# Placeholder for future personalized recommendations
st.markdown("### Personalized Learning Materials")
st.info("Once your learning materials are available, personalized recommendations will be displayed here.")

