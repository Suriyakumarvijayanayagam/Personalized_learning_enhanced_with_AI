import streamlit as st
import boto3
import re  # For password validation
from botocore.exceptions import ClientError
import requests  # For sending user queries to the processing API

# AWS configuration
AWS_REGION = 'ap-southeast-2'
USER_POOL_ID = 'ap-southeast-2_q6TnPRpD1'
CLIENT_ID = '1nutuc72conscagp5e5d38uc39'


# Directly setting AWS Access Key and Secret Key
AWS_ACCESS_KEY = 'AKIAY6QVZD7XVUEPRZ45'  # Replace with your access key
AWS_SECRET_KEY = 'VMTE+1rTcgDg1RDRvFpzKgn4j1tSWB0F4XZhVWXh'  # Replace with your secret key

# Initialize the Cognito client
client = boto3.client(
    'cognito-idp',
    region_name=AWS_REGION,
    aws_access_key_id=AWS_ACCESS_KEY,
    aws_secret_access_key=AWS_SECRET_KEY
)

# Initialize S3 client
s3_client = boto3.client(
    's3',
    aws_access_key_id=AWS_ACCESS_KEY,
    aws_secret_access_key=AWS_SECRET_KEY,
    region_name=AWS_REGION
)

# Function to validate the password
def is_valid_password(password):
    return {
        "min_length": len(password) >= 8,
        "uppercase": bool(re.search(r"[A-Z]", password)),
        "lowercase": bool(re.search(r"[a-z]", password)),
        "digit": bool(re.search(r"\d", password)),
        "special_char": bool(re.search(r"[!@#$%^&*]", password))
    }

# Function to sign up a new user with role
def sign_up(email, password, role):
    try:
        response = client.sign_up(
            ClientId=CLIENT_ID,
            Username=email,
            Password=password,
            UserAttributes=[
                {"Name": "email", "Value": email},
                {"Name": "custom:role", "Value": role},  # 'instructor' or 'student'
            ],
        )
        st.success("Sign up successful! Please check your email for the verification code.")
        st.session_state['email'] = email  # Save email for verification
        st.session_state['signup_completed'] = True
        return response
    except ClientError as e:
        st.error(f"Error signing up: {e.response['Error']['Message']}")
        return None

# Function to verify user's email
def verify_email(email, verification_code):
    try:
        response = client.confirm_sign_up(
            ClientId=CLIENT_ID,
            Username=email,
            ConfirmationCode=verification_code,
        )
        st.success("Email verified successfully!")
        st.session_state['signup_completed'] = False
        return response
    except ClientError as e:
        st.error(f"Error verifying email: {e.response['Error']['Message']}")
        return None

# Function to sign in a user
def sign_in(email, password):
    try:
        response = client.initiate_auth(
            ClientId=CLIENT_ID,
            AuthFlow='USER_PASSWORD_AUTH',
            AuthParameters={'USERNAME': email, 'PASSWORD': password},
        )
        st.session_state.tokens = response['AuthenticationResult']
        st.success("Sign in successful!")
        
        # Retrieve user role and store in session state
        user_info = client.get_user(AccessToken=st.session_state.tokens['AccessToken'])
        for attribute in user_info['UserAttributes']:
            if attribute['Name'] == 'custom:role':
                st.session_state['role'] = attribute['Value']
        st.session_state['username'] = email
    except ClientError as e:
        st.error(f"Error signing in: {e.response['Error']['Message']}")

# Function to upload document to S3 for instructors
def upload_document_to_s3(file, username):
    try:
        s3_client.upload_fileobj(
            Fileobj=file,
            Bucket='your-s3-bucket-name',
            Key=f'documents/{username}/{file.name}'
        )
        st.success("Document uploaded successfully!")
    except ClientError as e:
        st.error(f"Error uploading document: {e.response['Error']['Message']}")

# Function to send a user query to the processing API
def send_query(query, username):
    response = requests.post(
        'https://your-api-endpoint.com/query',
        json={'query': query, 'username': username}
    )
    return response.json()

# Main function to manage Streamlit app flow
def main():
    st.title("User Authentication and Document Query System")

    # Choose between Sign Up and Sign In
    choice = st.sidebar.selectbox("Choose Option", ["Sign Up", "Sign In"])

    if choice == "Sign Up":
        st.subheader("Sign Up")

        # Sign up form
        if not st.session_state.get('signup_completed'):
            email = st.text_input("Email")
            password = st.text_input("Password", type="password")
            role = st.selectbox("Select Role", ["student", "instructor"])

            # Display password requirements
            if password:
                checks = is_valid_password(password)
                st.write("Password Requirements:")
                st.write("- Minimum 8 characters: " + ("✅" if checks["min_length"] else "❌"))
                st.write("- At least 1 uppercase letter: " + ("✅" if checks["uppercase"] else "❌"))
                st.write("- At least 1 lowercase letter: " + ("✅" if checks["lowercase"] else "❌"))
                st.write("- At least 1 digit: " + ("✅" if checks["digit"] else "❌"))
                st.write("- At least 1 special character (!@#$%^&*): " + ("✅" if checks["special_char"] else "❌"))

            if st.button("Sign Up"):
                if email and password:
                    if all(is_valid_password(password).values()):
                        sign_up(email, password, role)
                    else:
                        st.warning("Please make sure your password meets all requirements.")
                else:
                    st.warning("Please provide both email and password.")
        
        # Verification form
        if st.session_state.get('signup_completed'):
            st.subheader("Verify Email")
            verification_code = st.text_input("Enter Verification Code")
            if st.button("Verify Email"):
                if verification_code:
                    verify_email(st.session_state['email'], verification_code)
                else:
                    st.warning("Please enter the verification code sent to your email.")

    elif choice == "Sign In":
        st.subheader("Sign In")
        email = st.text_input("Email")
        password = st.text_input("Password", type="password")

        if st.button("Sign In"):
            if email and password:
                sign_in(email, password)
            else:
                st.warning("Please provide both email and password.")

    # Portal access after successful sign-in
    if 'tokens' in st.session_state:
        if st.session_state['role'] == 'instructor':
            st.subheader("Instructor Portal")
            uploaded_file = st.file_uploader("Upload Document", type=["pdf", "docx"])
            if uploaded_file:
                upload_document_to_s3(uploaded_file, st.session_state['username'])

        st.subheader("Ask a Question")
        query = st.text_input("Enter your question about the documents:")
        if st.button("Submit Query"):
            if query:
                response = send_query(query, st.session_state['username'])
                st.write("Answer:", response.get("answer", "No relevant answer found."))

# Initialize session state variables
if 'signup_completed' not in st.session_state:
    st.session_state['signup_completed'] = False

if __name__ == "__main__":
    main()
