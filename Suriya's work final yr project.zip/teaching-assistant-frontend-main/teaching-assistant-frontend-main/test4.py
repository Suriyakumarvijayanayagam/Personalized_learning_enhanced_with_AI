import streamlit as st
import boto3
import fitz  # PyMuPDF for PDF text extraction
from botocore.exceptions import ClientError
from sentence_transformers import SentenceTransformer, util
import pandas as pd
import time
import os

# AWS S3 configuration
AWS_REGION = 'ap-southeast-2'
S3_BUCKET_NAME = 'projectblank'
s3_client = boto3.client(
    's3',
    region_name=AWS_REGION
)

# Load a transformer model for semantic search
model = SentenceTransformer('paraphrase-MiniLM-L6-v2')

# Professor configuration (map professors to S3 prefixes)
PROFESSOR_CONFIG = {
    "drvinay": {"s3_prefix": "drvinay/"},
    "lewas": {"s3_prefix": "lewas/"},
    "historyoftech": {"s3_prefix": "historyoftech/"}
}

def extract_text_from_pdf(file):
    """Extract text from a PDF file using PyMuPDF."""
    doc = fitz.open(stream=file.read(), filetype="pdf")
    text = ""
    for page in doc:
        text += page.get_text()
    doc.close()
    return text

def process_and_upload_pdf_content(file, professor):
    """Extract, process, and store PDF content."""
    pdf_text = extract_text_from_pdf(file)
    s3_key = f"{PROFESSOR_CONFIG[professor]['s3_prefix']}processed_content/{file.name}.txt"
    try:
        s3_client.put_object(Bucket=S3_BUCKET_NAME, Key=s3_key, Body=pdf_text)
        return s3_key
    except ClientError as e:
        st.error(f"Error uploading processed content to S3: {e}")
        return None

def upload_to_s3(file, professor):
    """Upload a file to S3 for the selected professor."""
    s3_prefix = PROFESSOR_CONFIG[professor]["s3_prefix"]
    s3_key = f"{s3_prefix}{file.name}"
    try:
        s3_client.upload_fileobj(file, S3_BUCKET_NAME, s3_key)
        return s3_key
    except ClientError as e:
        st.error(f"Error uploading file to S3: {e}")
        return None

def fetch_documents(professor):
    """Fetch and prepare documents for the selected professor."""
    documents = get_professor_documents(professor)
    documents.sort(key=lambda x: x["Upload Date"], reverse=True)  # Sort by newest first
    return documents

def get_s3_documents(professor):
    """Retrieve documents from S3 for the given professor."""
    s3_prefix = PROFESSOR_CONFIG[professor]["s3_prefix"]
    try:
        response = s3_client.list_objects_v2(Bucket=S3_BUCKET_NAME, Prefix=s3_prefix)
        documents = []
        for obj in response.get("Contents", []):
            documents.append({
                "Document Name": os.path.basename(obj["Key"]),
                "Upload Date": obj["LastModified"].strftime("%Y-%m-%d %H:%M:%S"),
                "Size (bytes)": obj["Size"],
                "Processed": "No" if "processed_content" not in obj["Key"] else "Yes"
            })
        return documents
    except ClientError as e:
        st.error(f"Error retrieving S3 documents: {e}")
        return []

def get_professor_documents(professor):
    """Combine S3 and processed documents for the professor."""
    s3_documents = get_s3_documents(professor)
    processed_documents = set()  # Placeholder for processed documents
    combined_documents = []
    for doc in s3_documents:
        combined_documents.append({
            "Document Name": doc["Document Name"],
            "Upload Date": doc["Upload Date"],
            "Size (bytes)": doc["Size (bytes)"],
            "Processed": "Yes" if doc["Processed"] == "Yes" else "No",
        })
    return combined_documents

def search_pdf_content(user_query, professor):
    """Match user query with processed PDF content."""
    s3_prefix = PROFESSOR_CONFIG[professor]["s3_prefix"] + "processed_content/"
    response = s3_client.list_objects_v2(Bucket=S3_BUCKET_NAME, Prefix=s3_prefix)
    matching_text = []

    for obj in response.get("Contents", []):
        file_obj = s3_client.get_object(Bucket=S3_BUCKET_NAME, Key=obj["Key"])
        content = file_obj["Body"].read().decode("utf-8")

        # Use model embeddings for semantic similarity check
        user_embed = model.encode(user_query, convert_to_tensor=True)
        content_embed = model.encode(content, convert_to_tensor=True)
        similarity_score = util.pytorch_cos_sim(user_embed, content_embed).item()

        if similarity_score > 0.75:  # Set a threshold for relevance
            matching_text.append({"document": obj["Key"], "content": content, "score": similarity_score})

    return matching_text

def instructor_portal():
    """Instructor Portal UI and functionality."""
    st.title("Instructor Portal")

    # Dropdown for professor selection
    professor = st.selectbox("Select Professor", list(PROFESSOR_CONFIG.keys()))

    # File upload functionality
    uploaded_file = st.file_uploader("Choose a file to upload", type=["pdf"])
    if uploaded_file:
        if st.button("Upload and Process File"):
            s3_key = upload_to_s3(uploaded_file, professor)
            if s3_key:
                st.success(f"File '{uploaded_file.name}' uploaded successfully!")
                process_key = process_and_upload_pdf_content(uploaded_file, professor)
                if process_key:
                    st.success(f"File '{uploaded_file.name}' processed and content uploaded successfully!")
                else:
                    st.error("Failed to process and upload content.")
            else:
                st.error("Failed to upload file. Please try again.")

    # Fetch and display documents in a table
    documents = fetch_documents(professor)
    if documents:
        documents = [doc for doc in documents if doc["Size (bytes)"] > 0]
        df = pd.DataFrame(documents)
        df = df[["Document Name", "Upload Date", "Size (bytes)", "Processed"]]  # Reorder columns
        st.table(df.set_index("Document Name"))

    # Refresh button
    if st.button("Refresh Document Status"):
        st.rerun()

def chatbot_interface():
    """Display chatbot interface for answering questions."""
    st.title("Educational Query Assistant")
    user_query = st.text_input("Ask a question about the uploaded documents:")
    professor = st.selectbox("Select Professor", list(PROFESSOR_CONFIG.keys()))

    if user_query and st.button("Submit Query"):
        matching_texts = search_pdf_content(user_query, professor)
        if matching_texts:
            st.write("Results:")
            for match in matching_texts:
                st.write(f"**Document**: {match['document']} - **Score**: {match['score']}")
                st.write(match["content"][:500] + "...")  # Display a snippet
        else:
            st.write("No relevant information found.")

def main():
    """Main function for the Streamlit application."""
    st.sidebar.title("Main Menu")
    st.sidebar.subheader("Educational Query Assistant")

    # Instructor Portal view
    st.sidebar.write("Instructor Portal")
    instructor_portal()

    # Chatbot view
    st.sidebar.write("Chatbot Interface")
    chatbot_interface()

if __name__ == "__main__":
    main()
