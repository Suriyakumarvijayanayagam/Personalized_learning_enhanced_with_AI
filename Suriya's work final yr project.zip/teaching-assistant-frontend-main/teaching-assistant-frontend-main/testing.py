import boto3
from botocore.exceptions import ClientError

# Configuration
AWS_REGION = 'ap-southeast-2'  # e.g., 'us-east-1'
USER_POOL_ID = 'ap-southeast-2_q6TnPRpD1'
CLIENT_ID = '1nutuc72conscagp5e5d38uc39'

# Directly setting AWS Access Key and Secret Key
AWS_ACCESS_KEY = 'AKIAY6QVZD7XVUEPRZ45'  # Replace with your access key
AWS_SECRET_KEY = 'VMTE+1rTcgDg1RDRvFpzKgn4j1tSWB0F4XZhVWXh'  # Replace with your secret key

# Initialize the Cognito client
client = boto3.client('cognito-idp', region_name=AWS_REGION,
                      aws_access_key_id=AWS_ACCESS_KEY,
                      aws_secret_access_key=AWS_SECRET_KEY)

def sign_up(email, password):
    try:
        response = client.sign_up(
            ClientId=CLIENT_ID,
            Username=email,
            Password=password,
            UserAttributes=[{"Name": "email", "Value": email}],
        )
        print("Sign up successful! Please check your email for the verification code.")
        return response
    except ClientError as e:
        print(f"Error signing up: {e.response['Error']['Message']}")
        return None

def verify_email(email, verification_code):
    try:
        response = client.confirm_sign_up(
            ClientId=CLIENT_ID,
            Username=email,
            ConfirmationCode=verification_code,
        )
        print("Email verified successfully!")
        return response
    except ClientError as e:
        print(f"Error verifying email: {e.response['Error']['Message']}")
        return None

def sign_in(email, password):
    try:
        response = client.initiate_auth(
            ClientId=CLIENT_ID,
            AuthFlow='USER_PASSWORD_AUTH',
            AuthParameters={
                'USERNAME': email,
                'PASSWORD': password,
            },
        )
        print("Sign in successful!")
        return response['AuthenticationResult']
    except ClientError as e:
        print(f"Error signing in: {e.response['Error']['Message']}")
        return None

def check_user_exists(email):
    try:
        response = client.admin_get_user(
            UserPoolId=USER_POOL_ID,
            Username=email
        )
        return response  # User exists
    except ClientError as e:
        if e.response['Error']['Code'] == 'UserNotFoundException':
            print("User does not exist.")
            return None
        else:
            print(f"Error checking user existence: {e.response['Error']['Message']}")
            return None

def main():
    while True:
        print("\nSelect an option:")
        print("1. Sign Up")
        print("2. Sign In")
        print("3. Exit")
        
        choice = input("Enter your choice (1/2/3): ")
        
        if choice == '1':
            # Sign Up Process
            email = input("Enter your email: ")
            password = input("Enter your password: ")
            sign_up_response = sign_up(email, password)

            if sign_up_response:
                # Verify Email
                verification_code = input("Enter the verification code sent to your email: ")
                verify_email_response = verify_email(email, verification_code)

        elif choice == '2':
            # Sign In Process
            email = input("Enter your email: ")
            password = input("Enter your password: ")
            check_user_response = check_user_exists(email)

            if check_user_response:
                sign_in_response = sign_in(email, password)
                if sign_in_response:
                    print("Access Token:", sign_in_response['AccessToken'])
                    print("ID Token:", sign_in_response['IdToken'])
                    print("Refresh Token:", sign_in_response['RefreshToken'])

        elif choice == '3':
            print("Exiting the program.")
            break
        else:
            print("Invalid choice. Please select again.")

# Run the main function
if __name__ == "__main__":
    main()
